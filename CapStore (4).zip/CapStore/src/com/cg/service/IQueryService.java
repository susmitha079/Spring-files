package com.cg.service;

import com.cg.entities.Coupons;
import com.cg.entities.Inventory;

public interface IQueryService {

	// List<QueryAnswers> getall();
void plp();
public abstract Coupons save(Coupons coupons);
public abstract Inventory save1(Inventory inventory);

}
