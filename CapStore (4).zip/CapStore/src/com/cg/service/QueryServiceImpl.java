package com.cg.service;



import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDAO;
import com.cg.entities.Coupons;
import com.cg.entities.Inventory;


@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDAO iQueryDAO;
	
	

	@Override
	public void plp() {
		iQueryDAO.plp();
	}



	@Override
	public Coupons save(Coupons coupons) {
		// TODO Auto-generated method stub
		return iQueryDAO.save(coupons);
	}



	@Override
	public Inventory save1(Inventory inventory) {
		// TODO Auto-generated method stub
		return iQueryDAO.save1(inventory);
	}



	



	

	
}
