package com.cg.dao;

import com.cg.entities.Coupons;
import com.cg.entities.Inventory;


public interface IQueryDAO {
	
	void plp();
	public abstract Coupons save(Coupons coupons);
	public abstract Inventory save1(Inventory inventory);
	
}
