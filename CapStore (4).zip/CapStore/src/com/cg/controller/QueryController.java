package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Coupons;
import com.cg.entities.Inventory;
import com.cg.service.IQueryService;

@Controller
public class QueryController {
	
	@Autowired
	IQueryService iQueryService;
	Coupons coupon;
	Inventory inventory;
	
	
	@RequestMapping("/index")
	public String index(Model model) {
	
		return "index";
	}
	@RequestMapping("/gc")
	public String getpromo(Model model,@ModelAttribute("Coupons")Coupons coupon) {
		model.addAttribute("Coupons",coupon);
		//System.out.println(coupon);
		//iQueryService.plp();
		return "gc";
	
}
	@RequestMapping("/save")
	public String  saveEmploy(@ModelAttribute("coupons") Coupons coupons,Model model) {
		coupon=(Coupons) iQueryService.save(coupons);
		return "index";
	}
	@RequestMapping("/discount")
	public String getdiscount(Model model,@ModelAttribute("Inventory")Inventory inventory) {
		model.addAttribute("Inventory",inventory);
		//System.out.println(coupon);
		//iQueryService.plp();
		return "discount";
	
}
	@RequestMapping("/savediscount")
	public String  saveDISCOUNT(@ModelAttribute("inventory") Inventory inventory,Model model) {
		inventory=(Inventory) iQueryService.save1(inventory);
		return "index";
	}
}
