package com.ss.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.ss.entities.ScheduledSessions;

@Repository
public class SessionRepositoryImpl implements SessionRepository
{
	
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<ScheduledSessions> showSessions() 
	{
		TypedQuery<ScheduledSessions> query = entityManager.createQuery("select s from ScheduledSessions s",ScheduledSessions.class);
		return query.getResultList();
	}
}
