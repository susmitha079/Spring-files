package com.ss.dao;

import java.util.List;

import com.ss.entities.ScheduledSessions;

public interface SessionRepository 
{
	List<ScheduledSessions> showSessions();
}
