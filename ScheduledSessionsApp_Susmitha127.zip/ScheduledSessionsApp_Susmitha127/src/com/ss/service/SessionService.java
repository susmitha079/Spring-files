package com.ss.service;

import java.util.List;

import com.ss.entities.ScheduledSessions;

public interface SessionService {

	List<ScheduledSessions> showSessions();

}
